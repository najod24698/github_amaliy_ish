import './App.css';
import Header from './components/Header';
// import Login from './components/Login';  
import LoginEmailPassword from './components/LoginEmailPassword';

function App() {

  const user = null;
  return (
    <div className="App">
      { !user ?
      < LoginEmailPassword />
        :
        <Header />
      }

    </div>
  );
}

export default App;
