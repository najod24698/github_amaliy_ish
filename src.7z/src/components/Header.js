import React from 'react';
import { useState } from 'react';
import '../styles/Header.css';
import RoomOutlinedIcon from '@material-ui/icons/RoomOutlined';
import SearchIcon from '@material-ui/icons/Search';
import lang from '../assets/us.svg';
import ArrowDropDownIcon from '@material-ui/icons/ArrowDropDown';
import cart from '../assets/cart.svg';

function Header() {
    const [showup, setshowup] = useState(true);

    const createline = (e) => {
        if (!showup) {
            e.target.parentElement.classList.add("createline");
            setshowup(true);
        }
        else {
            e.target.parentElement.classList.remove("createline");
            setshowup(false);
        }
    }

    const showTheLangaugeBar = (e) => {
        const langaugeBar = document.querySelector('.langauge_bar');
        if(!showup){
            langaugeBar.classList.add('active');
        }
        else {
            console.log("done");
        }
        setshowup(true);
    }


    const hideTheLangaugeBar = (e) => {
        const langaugeBar = document.querySelector('.langauge_bar');
        if(showup) {
            langaugeBar.classList.remove("active");
            setshowup(false);
        } else {
            console.log("done");
        }
    }



    return (
        <div className="header">
            <img className="header_logo" src="https://pngimg.com/uploads/amazon/amazon_PNG25.png" alt="amazon" />
            <div className="delivery">
                <RoomOutlinedIcon />
                <div className="deliver">
                    <span>Delivery to</span>
                    <h2>Uzbekistan</h2>
                </div>
            </div>
            <div className="search_bar">
                <select id="category">
                    <option value="all">All</option>
                    <option value="Clothes">Clothes</option>
                    <option value="Smartphones">Smartphones</option>
                    <option value="Laptops">Laptops</option>
                    <option value="Watches">Watches</option>
                </select>
                <input type="search" placeholder="Search" id="search" onClick={createline} />
                <div className="search_icon">
                    <SearchIcon />
                </div>
            </div>
            <div className="account">
                <div className="langauga" onMouseEnter={showTheLangaugeBar} onMouseLeave={hideTheLangaugeBar}>
                    <img src={lang} alt="" className="lang_img" />
                    <ArrowDropDownIcon />
                    <div className="langauge_bar"></div>
                </div>
                <div className="sign_in_out">
                    <div className="sign">
                        <span>Hello, sign in</span>
                        <h4>Account&Lists</h4>
                    </div>
                    <ArrowDropDownIcon className="sign_icon" />
                </div>
                <div className="orders">
                    <span>Return</span>
                    <h4>&Orders</h4>
                </div>
                <div className="cart">
                    <div className="counter">0</div>
                    <img src={cart} alt="" id="image_order"/>
                    <h4>Cart</h4>
                </div>
            </div>
        </div>
    )
}

export default Header;