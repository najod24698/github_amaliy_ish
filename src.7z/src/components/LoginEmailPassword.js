import React from 'react';
import {useState} from 'react';
import '../styles/LoginEmailPassword.css';
import amazonqora from '../assets/amazonqora.png';
import ArrowRightIcon from '@material-ui/icons/ArrowRight';


function LoginEmail() {

    const [showup, setshowup] = useState(false);


    const need_help = (e) => {                      
         const need_help_p = document.querySelector('.need_help_p');
      
        if(!showup) {
            need_help_p.classList.add(".ddddd");
            setshowup(false);
        } else {
            console.log("chiqmadi");
        }
        setshowup(true);
    }



    return (
        <div className="loginEmailPassword">
            <img src={amazonqora} alt="" className="header_logo" alt="amazon" />
            <div className="loginContainer">
                <h1>Sign in</h1>
                <form action="#" id="form">
                    <label htmlFor="email">Email or mobile phone number</label>
                    <input type="email" id="email" />
                    <label htmlFor="password">password</label>
                    <input type="password" id="password" />
                    <button type="submit" className="btn_continue">Continue</button>
                </form>
                <div className="continue_off">
                    <p>By continuing, you agree to Amazon's <a href="#">Conditions of  Use</a> and <a href="#">Privacy Notice.</a></p>
                </div>
                <div className="need_help">
                    <div className="arrows"> 
                        <span className="arrow_right"><ArrowRightIcon /></span>
                        <p><a href="#" onClick={need_help}>Need help?</a></p>
                    </div>
                    <div className="need_help_p">
                        <p><a href="#">Forgot your password?</a></p>
                        <p><a href="#">Other issues with Sign-In</a></p>
                    </div>
                </div>
            </div>
        </div>
    )
}

export default LoginEmail
